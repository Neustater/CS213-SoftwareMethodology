/**
 * cafeGUI is a GUI based program
 * that handles the ordering of items at RU Cafe
 * @author Muhammad Faizan Saiyed, Michael Neustater
 */

package cafeGUI;
